# MIQAT – GitHub Deployment Guide

## Files to Upload
- index.html
- manifest.json  
- sw.js
- icons/ (add your app icon as icon-192.png and icon-512.png)

## Steps

### 1. GitHub pe New Repo banao
- github.com pe jao
- New Repository → name: `MIQAT`
- Public rakho
- Create Repository

### 2. Files Upload karo
- Upload files button tap karo
- Teeno files drag karo (index.html, manifest.json, sw.js)
- Commit changes

### 3. GitHub Pages Enable karo
- Settings → Pages
- Source: Deploy from branch
- Branch: main → / (root)
- Save

### 4. Live URL
- 2-3 minutes baad:
- https://[username].github.io/MIQAT

## Phone Pe Install Karna (PWA)
1. Chrome mein URL kholo
2. Menu (3 dots) → "Add to Home Screen"
3. Install tap karo
4. Done! App icon home screen pe aa jayega
